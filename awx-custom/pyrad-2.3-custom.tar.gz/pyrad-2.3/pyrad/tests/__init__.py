import pyrad
import sys

pyrad  # keep pyflakes happy
home = sys.modules["pyrad"].__path__[0]
